import json
import fileCrawler
import chatbotRequest
import summarizeDocs

from flask import Flask, render_template,url_for , jsonify,request, redirect, send_file
import webbrowser

app = Flask(__name__, static_url_path='/static')

@app.route('/')
def index():
    return render_template('front-page.html')

@app.route('/searchDir',methods=['POST'])
def clicked():
	searchPathObject = request.data
	searchPathObject = json.loads(searchPathObject)
	searchPath = searchPathObject[u'search']
	searchPath = fileCrawler.crawlFiles(searchPath)
	print "File Crawled"
	summarizeDocs.summarizeDoc()
	print "Summarized Docs"
	return searchPath
	
@app.route('/searchPage')
def searchPage():
	return render_template('searchPagenew.html')
	
@app.route('/search/<searchTopic>')
def search(searchTopic):
	results = chatbotRequest.search(searchTopic)
	return jsonify(results)

@app.route('/openFile', methods=['POST'])
def openFile():
	da = request.data
	da = json.loads(da)
	filename = da[u'name']
	id = da[u'id']
	filename = chatbotRequest.openFile(id,filename)
	webbrowser.open(filename)
	return jsonify(filename)

@app.route('/positiveFeedback',methods=['POST'])
def positive():
	#filename = listbox.get(ACTIVE)
	#id = entries[filename]
	id = request.data
	id = json.loads(id)
	id = id[u'id']
	searchTopic = request.data
	searchTopic = json.loads(searchTopic)
	searchTopic = searchTopic[u'searchTopic']
	id = chatbotRequest.positive(id,searchTopic)
	return jsonify(id)

@app.route('/negativeFeedback',methods=['POST'])
def negative():
	#filename = listbox.get(ACTIVE)
	#id = entries[filename]
	id = request.data
	id = json.loads(id)
	id = id[u'id']
	searchTopic = request.data
	searchTopic = json.loads(searchTopic)
	searchTopic = searchTopic[u'searchTopic']
	id = chatbotRequest.negative(id,searchTopic)
	return jsonify(id)
	
if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0')
	