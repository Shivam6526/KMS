from flask import Flask, render_template,url_for , jsonify,request, redirect, send_file
import json
app = Flask(__name__, static_url_path='/static')

class InvalidUsage(Exception):
    status_code = 400

    def __init__(self, message, status_code=None, payload=None):
        Exception.__init__(self)
        self.message = message
        if status_code is not None:
            self.status_code = status_code
        self.payload = payload

    def to_dict(self):
        rv = dict(self.payload or ())
        rv['message'] = self.message
        return rv

@app.route('/')
def index():
	return render_template('download_Test.html')
	
@app.route('/downloadFile', methods=['POST'])
def downloadFile():
	da = request.data
	da = json.loads(da)
	path = da[u'name']
	if path is None:
		print "Error!"
	return send_file(path, as_attachment=True)
	
if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0')