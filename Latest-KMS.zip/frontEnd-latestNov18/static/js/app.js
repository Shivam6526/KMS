var app = angular.module("tutorial",['ngSanitize']);

app.controller('MyCtrl', function ($scope, $http) {
      $scope.searchTopic = "";
      $scope.testValue = "";
      $scope.result = [];
      $scope.show = [];
      
	  $scope.search = function () {

            var search = $scope.searchTopic;
            console.log(search);
           
            $http.get('/search/'+ search).then(successCallback, errorCallback);

            function successCallback(response){
                     $scope.show = [];
                $scope.result = response.data;
                for(i=0;i<$scope.result.length;i++){
                        $scope.show.push(false);
                        }
            }
            function errorCallback(error){
                 console.log("failed");
            }
      }
      
	  $scope.showPopover = function(index){
              $scope.show[index] = true;
      }
      
	  $scope.hidePopover = function(index){
              $scope.show[index] = false;
      }
      
	  $scope.open = function (name,id) {

            var data = {"name":name,"id":id};
            var config = {};
            console.log("open file name "+name);
            $http.post('/openFile', data, config).then(successCallback, errorCallback);

            function successCallback(response){
                 var x = response.data;
                 
            }
            function errorCallback(error){
                 console.log("failed");
            }
     
      }
          


      $scope.feedback = function (id,value) {

            var data = {"id":id,"searchTopic":$scope.searchTopic};
            var config = {};
            console.log(open);
            if(value == 1){
				$http.post('/positiveFeedback', data, config).then(successCallback, errorCallback);
            }else{
				$http.post('/negativeFeedback', data, config).then(successCallback, errorCallback);
            }


            function successCallback(response){
                 var x = response.data;
                 modal.style.display = "block";
                 $scope.search();
            }
            function errorCallback(error){
                 console.log("failed");
            }

      }
        var modal = document.getElementById('myModal');


		// Get the <span> element that closes the modal
		var span = document.getElementsByClassName("close")[0];


		// When the user clicks on <span> (x), close the modal
		span.onclick = function() {
			modal.style.display = "none";
		}

		// When the user clicks anywhere outside of the modal, close it
		window.onclick = function(event) {
			if (event.target == modal) {
				modal.style.display = "none";
			}
		}

});