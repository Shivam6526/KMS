var app = angular.module('frontPageApp',['ngSanitize']);

app.controller('frontPageCtrl',function($scope,$http,$window){
	$scope.searchPath = "";
	$scope.loaderGif = false;
	$scope.search = function(){
		var search = $scope.searchPath;
		console.log(search);
		data = {"search":search};
		config = {};
		$scope.loaderGif=true;
		$http.post('/searchDir', data, config).then(successCallback, errorCallback);
		function successCallback(response){
			console.log(response.data);
			console.log("fileCrawler success!");
			$scope.loaderGif=false;
			$window.location.href = '/searchPage';
		}
		function errorCallback(response){
			$scope.loaderGif=false;
			console.log(response.data);
			console.log("failed!");
		}
	}
});